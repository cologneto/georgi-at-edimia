<?php

/* drop_area.html */
class __TwigTemplate_8fdd4775a57c5cef695192c24f3c3a92262d167fa80243557d1f890ec5d0fbd6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div id=\"drop-area\" class=\"animated bounceInLeft\">
    <div class=\"drop-target\" style=\"left: 0px; position: relative; display: block;\"><div style=\"font-size: 5em; color: #FFFFFF; position: absolute; width: 160px; line-height: 160px; margin-bottom: 10px;\" class=\"exe-task\">
            <div style=\"width: 160px; \" class=\"number_image_holder answerrow animated bounceInLeft\">

            </div>
        </div>
        <div style=\"font-size: 5em; color: #000000; position: absolute; width: 50px; left: 175px; line-height: 160px; margin-bottom: 10px;\" class=\"exe-eq\">
            =
        </div>
        <div style=\"color: #000000; position: absolute; width: 160px; left: 240px; line-height: 160px; margin-bottom: 10px; border: 1px solid red; height: 160px;\" class=\"drophere ui-droppable\">

        </div>    
    </div>
    <div class=\"drop-target\" style=\"left: 0px; position: relative; display: block;\"><div style=\"font-size: 5em; color: #FFFFFF; position: absolute; width: 160px; line-height: 160px; margin-bottom: 10px;\" class=\"exe-task\">
            <div style=\"width: 160px; \" class=\"number_image_holder answerrow animated bounceInLeft\">

            </div>
        </div>
        <div style=\"font-size: 5em; color: #000000; position: absolute; width: 50px; left: 175px; line-height: 160px; margin-bottom: 10px;\" class=\"exe-eq\">
            =
        </div>
        <div style=\"color: #000000; position: absolute; width: 160px; left: 240px; line-height: 160px; margin-bottom: 10px; border: 1px solid red; height: 160px;\" class=\"drophere ui-droppable\">

        </div>
    </div>
    <div class=\"drop-target\" style=\"left: 0px; position: relative; display: block;\"><div style=\"font-size: 5em; color: #FFFFFF; position: absolute; width: 160px; line-height: 160px; margin-bottom: 10px;\" class=\"exe-task\">
            <div style=\"width: 160px; \" class=\"number_image_holder answerrow animated bounceInLeft\">

            </div>
        </div>
        <div style=\"font-size: 5em; color: #000000; position: absolute; width: 50px; left: 175px; line-height: 160px; margin-bottom: 10px;\" class=\"exe-eq\">
            =
        </div>
        <div style=\"color: #000000; position: absolute; width: 160px; left: 240px; line-height: 160px; margin-bottom: 10px; border: 1px solid red; height: 160px;\" class=\"drophere ui-droppable\">

        </div>
    </div>
</div>";
    }

    public function getTemplateName()
    {
        return "drop_area.html";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }
}
