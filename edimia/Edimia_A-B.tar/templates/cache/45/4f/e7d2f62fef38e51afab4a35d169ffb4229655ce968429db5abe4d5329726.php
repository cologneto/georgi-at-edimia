<?php

/* drag_targets.html */
class __TwigTemplate_454fe7d2f62fef38e51afab4a35d169ffb4229655ce968429db5abe4d5329726 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div id=\"drag-targets\">
    <div class=\"answer-drag\" style=\"top: 0px;\">
        <div style=\"width: 160px; \" class=\"number_image_holder\">

        </div>
    </div>
    <div class=\"answer-drag\" style=\"top: 180px;\">
        <div style=\"width: 160px; \" class=\"number_image_holder\">

        </div>
    </div>
    <div class=\"answer-drag\" style=\"top: 360px;\">
        <div style=\"width: 160px; \" class=\"number_image_holder\">

        </div>
    </div>
</div>";
    }

    public function getTemplateName()
    {
        return "drag_targets.html";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }
}
